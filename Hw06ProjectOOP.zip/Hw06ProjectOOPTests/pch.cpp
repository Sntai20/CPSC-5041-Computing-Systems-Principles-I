// Remembering to define _CRT_RAND_S prior
// to inclusion statement.
#define _CRT_RAND_S

// pch.cpp: source file corresponding to the pre-compiled header

#include "pch.h"

// When you are using pre-compiled headers, this source file is necessary for compilation to succeed.

